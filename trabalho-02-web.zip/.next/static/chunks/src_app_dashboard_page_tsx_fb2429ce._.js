(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_recharts_es6_93918282._.js",
  "static/chunks/node_modules_57981fc7._.js",
  "static/chunks/src_e515bb5f._.js"
],
    source: "dynamic"
});
