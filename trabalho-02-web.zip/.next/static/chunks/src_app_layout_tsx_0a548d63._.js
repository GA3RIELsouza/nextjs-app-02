(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_91e4631d.css",
  "static/chunks/node_modules_@firebase_auth_dist_esm_d3951ae3._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm_af799df8.js",
  "static/chunks/node_modules_486d7552._.js",
  "static/chunks/src_15c8bcce._.js"
],
    source: "dynamic"
});
