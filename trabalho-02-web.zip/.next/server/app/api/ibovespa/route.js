var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ibovespa/route.js")
R.c("server/chunks/node_modules_next_0314148c._.js")
R.c("server/chunks/[root-of-the-server]__509b8c65._.js")
R.m("[project]/.next-internal/server/app/api/ibovespa/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/ibovespa/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/ibovespa/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
