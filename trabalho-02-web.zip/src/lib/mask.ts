// Usar nomes em maiúsculo (SNAKE_CASE) é uma convenção para constantes.

export const PHONE_MASK = '(00) 00000-0000';

export const ZIP_CODE_MASK = '00000-000';

export const CPF_MASK = '000.000.000-00';