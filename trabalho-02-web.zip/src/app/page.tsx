import MainPage from "./main/page";
  
export default function Home() {
  return (
      <main className="flex flex-col min-h-screen p-4">
        <MainPage />
    </main>
  );
}
