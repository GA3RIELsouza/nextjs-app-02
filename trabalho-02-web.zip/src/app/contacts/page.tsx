import ContactSection from "@/components/pages/contacts/contactsection";

export default function ContactsPage() {
    return (
        <ContactSection />
    );
}
